package at.ac.univie.iot.data;

/**
 * Sensor type.
 */
public enum ESensor {
    TEMPERATURE,
    PRESSURE
}