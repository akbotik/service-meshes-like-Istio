package at.ac.univie.iot;

class IotApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
